
import Foundation

struct Product {
    enum Category {
        case electronics, clothing, food, books
    }
    
    let id: String
    let name: String
    let price: Double
    let category: Category
    let description: String
    
    var displayPrice: String {
        String(format: "$%.2f", price)  // format ceni
    }
    
    init?(name: String, price: Double, category: Category, description: String) {
        guard price > 0
        else {
            print("Error")
            return nil
            
        }
        
        self.id = UUID().uuidString
        self.name = name
        self.price = price
        self.category = category
        self.description = description
        
        
        
        
        
    }
}

struct CartItem {
    var product: Product
    private(set) var quantity: Int
    
    var subtotal: Double {
        product.price * Double(quantity)
    }
    
    mutating func updateQuantity(_ newQuantity: Int) {
        guard newQuantity > 0 else {return}
        quantity = newQuantity
    }
    
    mutating func increaseQuantity(by amount: Int) {
        guard amount > 0 else {return}
        quantity += amount
    }
}



class ShoppingCart {
    private(set) var items: [CartItem] = []
    var discountCode: String?
    
    func addItem(_ product: Product, quantity: Int = 1) {
        if let index = items.firstIndex(where: { $0.product.id == product.id }) {
            items[index].increaseQuantity(by: quantity)
        } else {
            items.append(CartItem(product: product, quantity: quantity))
        }
    }
    
    func removeItem(productId: String) {
        items.removeAll { $0.product.id == productId }
    }
    
    func updateItemQuantity(productId: String, quantity: Int) {
        guard let index = items.firstIndex(where: { $0.product.id == productId }) else { return }
        if quantity == 0 {
            removeItem(productId: productId)
        } else {
            items[index].updateQuantity(quantity)
        }
    }
    
    func clearCart() {
        items.removeAll()
    }
    
    var subtotal: Double {
        items.reduce(0) { $0 + $1.subtotal}
    }
    
    var discountAmount: Double {
        guard let code = discountCode else {return 0}
        switch code{
        case "SAVE10": return subtotal * 0.1
        case "SAVE20": return subtotal * 0.2
        default: return 0
        }
    }
    
    var total: Double{
        subtotal - discountAmount
    }
    
    var itemCount: Int {
        items.reduce(0) { $0 + $1.quantity }
    }
    var isEmpty: Bool {
        items.isEmpty
    }
    
}

struct Address {
    let country: String
    let city: String
    let zipCode: String
    let street: String
    
    var formatted: String {
        "\(country)\n\(city), \(zipCode)\n\(street)"
    }
}



// structura zakaza

struct Order {
    let id: String
    let items: [CartItem]
    let subtotal: Double
    let discount: Double
    let total: Double
    let date: Date
    let shippingAddress: Address
    
    init (from cart: ShoppingCart, to address: Address) {
        self.id = UUID().uuidString
        self.items = cart.items
        self.subtotal = cart.subtotal
        self.discount = cart.discountAmount
        self.total = cart.total
        self.date = Date()
        self.shippingAddress = address
    }
    
    var itemCount: Int {
        items.reduce(0) { $0 + $1.quantity }
    }
    
    
}



 let laptop = Product(name: "MacBook Pro", price: 3000, category: .electronics, description: "Apple laptop")!

let book = Product(name: "Prestuplenie i nakazanie", price: 10, category: .books, description: "Mirovaya classika")!

let rubashka = Product(name: "Rubashka Modnaya", price: 200, category: .clothing, description: "Prada Collection")!

let cart = ShoppingCart()
cart.addItem(laptop)
cart.addItem(book, quantity: 2)
cart.addItem(rubashka)
cart.discountCode = "SAVE10"

print("Items in the cart: \(cart.itemCount)")
print("Price without discount: \(cart.subtotal)")
print("Discount: \(cart.discountAmount)")
print("Total price: \(cart.total)\n")

let address = Address(country: "Kazakhstan", city: "Almaty", zipCode: "050009", street: "Tole Bi 59")

let order = Order(from: cart, to: address)

print("Zakaz sozdan: \(order.id)")
print("Tovarov v zakaze: \(order.itemCount)")
print("Address dostavki: \n\(order.shippingAddress.formatted)")

cart.clearCart()
print("Seichas v korzine:")
print("Tovarov v korzine:\(cart.itemCount)")
print("Tovarov v zakaze:\(order.itemCount)")
