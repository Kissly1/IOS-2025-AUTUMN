import Cocoa

let firstName: String = "Alexandr"
let lastName: String = "Kislitsin"
let birthYear: Int = 2005
let currentYear: Int = 2025
let age: Int = currentYear - birthYear
let univer: String = "KBTU"

let isStudent: Bool = true
let height: Double = 1.89

let hobby: String = "Games"
let numberOfHobbies: Int = 2
let favoriteNumber: Int = 31
let isHobbyCreative: Bool = false


var lifeStory = "My name is \(firstName) \(lastName). I'am \(age) years old,  I was born in \(birthYear). I'am a student \(isStudent), of university \(univer). My height is \(height). My favorite hobby is \(hobby), in general i have \(numberOfHobbies) hobbies. My favorite number \(favoriteNumber). Is my hobbies creative? - \(isHobbyCreative) "

let futureGoals: String = "In the future, I want to become a professional iOS developer😎"
print(lifeStory)
print(futureGoals)
