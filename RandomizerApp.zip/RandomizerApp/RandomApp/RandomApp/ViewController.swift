import UIKit

struct City {
    let name: String
    let imageName: String
    let description: String
    let country: String
    let population: String
}

class ViewController: UIViewController {
    
    @IBOutlet weak var cityImageView: UIImageView!
       @IBOutlet weak var cityNameLabel: UILabel!
       @IBOutlet weak var randomizeButton: UIButton!
       @IBOutlet weak var descriptionLabel: UILabel!
       @IBOutlet weak var countryLabel: UILabel!
       @IBOutlet weak var populationLabel: UILabel!
    
    let cities: [City] = [
        City(name: "Париж",
             imageName: "paris",
             description: "Город любви и света с Эйфелевой башней",
             country: "Франция",
             population: "2.2 млн"),
        
        City(name: "Токио",
             imageName: "tokyo",
             description: "Современная столица с древними традициями",
             country: "Япония",
             population: "14 млн"),
        
        City(name: "Нью-Йорк",
             imageName: "new_york",
             description: "Город, который никогда не спит",
             country: "США",
             population: "8.3 млн"),
        
        City(name: "Лондон",
             imageName: "london",
             description: "Историческая столица с Биг-Беном",
             country: "Великобритания",
             population: "9 млн"),
        
        City(name: "Дубай",
             imageName: "dubai",
             description: "Город будущего с небоскрёбами в пустыне",
             country: "ОАЭ",
             population: "3.5 млн"),
        
        City(name: "Рим",
             imageName: "rome",
             description: "Вечный город с Колизеем",
             country: "Италия",
             population: "2.8 млн"),
        
        City(name: "Сидней",
             imageName: "sydney",
             description: "Город с знаменитым оперным театром",
             country: "Австралия",
             population: "5.3 млн"),
        
        City(name: "Барселона",
             imageName: "barcelona",
             description: "Город Гауди и средиземноморского побережья",
             country: "Испания",
             population: "1.6 млн"),
        
        City(name: "Стамбул",
             imageName: "istanbul",
             description: "Город на двух континентах",
             country: "Турция",
             population: "15.5 млн"),
        
        City(name: "Сингапур",
             imageName: "singapore",
             description: "Город-государство будущего",
             country: "Сингапур",
             population: "5.7 млн")
    ]
    
    var currentCity: City?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        showRandomCity()
    }
    
    func setupUI() {
        cityImageView.contentMode = .scaleAspectFill
        cityImageView.clipsToBounds = true
        cityImageView.layer.cornerRadius = 16
        cityImageView.layer.shadowColor = UIColor.black.cgColor
        cityImageView.layer.shadowOpacity = 0.2
        cityImageView.layer.shadowOffset = CGSize(width: 0, height: 4)
        cityImageView.layer.shadowRadius = 8
        
        cityNameLabel.font = UIFont.boldSystemFont(ofSize: 28)
                cityNameLabel.textColor = .label
                cityNameLabel.textAlignment = .center
        
        randomizeButton.layer.cornerRadius = 12
        randomizeButton.backgroundColor = .systemBlue
        randomizeButton.setTitleColor(.white, for: .normal)
        randomizeButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        
        descriptionLabel?.numberOfLines = 0
        descriptionLabel?.textAlignment = .center
        descriptionLabel?.font = UIFont.systemFont(ofSize: 16)
        descriptionLabel?.textColor = .secondaryLabel
        
        countryLabel?.font = UIFont.systemFont(ofSize: 14)
        countryLabel?.textColor = .systemGray
        
        populationLabel?.font = UIFont.systemFont(ofSize: 14)
        populationLabel?.textColor = .systemGray
    }
    
    @IBAction func randomizeButtonTapped(_ sender: UIButton) {
        UIView.animate(withDuration: 0.1, animations: {
            sender.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        }) { _ in
            UIView.animate(withDuration: 0.1) {
                sender.transform = .identity
            }
        }
        
        showRandomCity()
    }
    
    func showRandomCity() {
        guard let randomCity = cities.randomElement() else { return }
        currentCity = randomCity
        
        UIView.transition(with: view, duration: 0.3, options: .transitionCrossDissolve, animations: {
            self.cityImageView.image = UIImage(named: randomCity.imageName)
            self.cityNameLabel.text = randomCity.name
            self.descriptionLabel?.text = randomCity.description
            self.countryLabel?.text = "🌍 \(randomCity.country)"
            self.populationLabel?.text = "👥 \(randomCity.population)"
        }, completion: nil)
    }
}
