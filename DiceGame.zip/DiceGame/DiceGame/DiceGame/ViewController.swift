import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var leftDiceImageView: UIImageView!
    @IBOutlet weak var rightDiceImageView: UIImageView!

    let diceImages = ["dice1", "dice2"]
    let diceSounds = ["dice1", "dice2"]

    var audioPlayer: AVAudioPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        rollDice(animated: false)
    }

    @IBAction func rollButtonPressed(_ sender: UIButton) {
        rollDice(animated: true)
    }

    func rollDice(animated: Bool) {
      
        playRandomDiceSound()

        if animated {
            UIView.animate(withDuration: 0.3, animations: {
                self.leftDiceImageView.transform = CGAffineTransform(rotationAngle: .pi)
                self.rightDiceImageView.transform = CGAffineTransform(rotationAngle: -.pi)
            }) { _ in
                // После анимации вернуть в норму
                UIView.animate(withDuration: 0.2) {
                    self.leftDiceImageView.transform = .identity
                    self.rightDiceImageView.transform = .identity
                }
            }
        }

        let left = diceImages.randomElement()!
        let right = diceImages.randomElement()!
        leftDiceImageView.image = UIImage(named: left)
        rightDiceImageView.image = UIImage(named: right)
    }

    func playRandomDiceSound() {
        guard let randomSound = diceSounds.randomElement(),
              let soundURL = Bundle.main.url(forResource: randomSound, withExtension: "mp3") else {
            print("⚠️ Файл звука не найден")
            return
        }

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
        } catch {
            print("Ошибка при воспроизведении звука: \(error)")
        }
    }
}
