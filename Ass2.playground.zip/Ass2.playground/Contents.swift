import Cocoa

// Problem 1
for i in 1...100 {
    if i % 3 == 0 && i % 5 == 0 {
        print("FizzBuzz")
    } else if i % 3 == 0 {
        print("Fizz")
    } else if i % 5 == 0 {
        print("Buzz")
    } else {
        print(i)
    }
}

// Problem 2


func isPrime(_ number: Int) -> Bool {
    if number < 2 { return false }
    for i in 2..<number {
        if number % i == 0 {
            return false
        }
    }
    return true
}

for i in 1...100 {
    if isPrime(i) {
        print(i)
    }
}



//Problem 3
func celsiusToFahrenheit(_ c: Double) -> Double { return c * 9/5 + 32 }
func celsiusToKelvin(_ c: Double) -> Double { return c + 273.15 }
func fahrenheitToCelsius(_ f: Double) -> Double { return (f - 32) * 5/9 }
func kelvinToCelsius(_ k: Double) -> Double { return k - 273.15 }

let value = 100.0
let unit = "C"

if unit == "C" {
    print("Fahrenheit:", celsiusToFahrenheit(value))
    print("Kelvin:", celsiusToKelvin(value))
} else if unit == "F" {
    let c = fahrenheitToCelsius(value)
    print("Celsius:", c)
    print("Kelvin:", celsiusToKelvin(c))
} else if unit == "K" {
    let c = kelvinToCelsius(value)
    print("Celsius:", c)
    print("Fahrenheit:", celsiusToFahrenheit(c))
}



// Problem 6
func fibonacci(_ n: Int) -> [Int] {
    if n <= 0 { return [] }
    if n == 1 { return [0] }
    var seq: [Int] = [0, 1]
    while seq.count < n {
        let next = seq[seq.count - 1] + seq[seq.count - 2]
        seq.append(next)
    }
    return seq
}


print(fibonacci(10))
